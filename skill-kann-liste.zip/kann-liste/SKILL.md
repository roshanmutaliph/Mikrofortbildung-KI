---
name: "kann-liste"
description: "Erstellt Kann-Listen als Word-Datei im Aufbau der Vorlage „XX Kann-Liste Kraft“ des Joseph-DuMont-Berufskollegs mit Schullogo. Immer nutzen, wenn eine Kann-Liste angefordert wird."
---

# Kann-Liste (Vorlage Joseph-DuMont-Berufskolleg)

Jede angeforderte Kann-Liste wird als **Word-Datei (.docx)** exakt im Aufbau der Vorlage „XX Kann-Liste Kraft“ erstellt – mit Schullogo, Kopf- und Fußzeile. Kein Artifact, kein Docs-Dokument, keine eigene Gestaltung. Die Datei wird immer direkt aus der Originalvorlage erzeugt (nur Inhalte austauschen), nie nachgebaut.

## Vorlage beschaffen
Die Vorlagendatei heißt „XX Kann-Liste Kraft - Kopie.docx“ (oder ähnlich, „Kann-Liste Kraft“ im Namen).
1. Wenn sie im Chat angehängt ist: diese verwenden.
2. Sonst, falls der Chat mit dem Computer des Nutzers verknüpft ist: in den verbundenen Ordnern danach suchen und ins Arbeitsverzeichnis holen.
3. Sonst den Nutzer kurz bitten, die Vorlage anzuhängen. Nicht ohne Vorlage bauen (das Logo steckt nur in der Datei).

## Aufbau der Vorlage (nicht verändern)
- **Kopfzeile** (Tahoma 8 pt): links „Fach“ + Fachname, darunter automatischer Dateiname; Mitte „HF X“ / „XX“, „AS“, „ZF“; rechts Logo „Joseph-DuMont-Berufskolleg“. Fußzeile rechts: „Seite | x von y“.
- **Titel** (fett): Kann-Liste „<Thema>“
- **Tabelle** (Tahoma): Kopfzeilen „Ich kann …“ und „Nr. | | TNW** | ✔“.
  - Themenzeilen: grau hinterlegt, fett, ganzzahlig nummeriert (1, 2, …).
  - Kompetenzzeilen: Nr. (1.1, 1.2, …) | Kompetenz als Fortsetzung von „Ich kann …“ (klein beginnend, endet mit Operator im Infinitiv: nennen, beschreiben, erklären, erläutern, begründen, voneinander abgrenzen …) | TNW** = Form des Nachweises (z. B. „Text“, „Stichpunkte“, „Stichpunkte/Tabelle“, „Skizze“) | leeres Häkchenfeld.

## Vorgehen
1. Inhalte festlegen: Thema (Titel), Fach (vom Nutzer, sonst aus dem Thema ableiten), Abschnitte mit Kompetenzen und TNW-Form. HF/AS/ZF bleiben Platzhalter („HF X“, „XX“, „AS“, „ZF“), außer der Nutzer nennt Werte.
2. Das Skript unten als `make_kannliste.py` speichern und die Inhalte als JSON anlegen:
   ```json
   {"titel": "Ausdauertraining", "fach": "Sport",
    "abschnitte": [{"titel": "Grundlagen", "punkte": [["den Begriff \"Ausdauer\" erklären", "Text"]]}]}
   ```
   Optionale Felder: "hf", "hf2", "as", "zf".
3. `python3 make_kannliste.py vorlage.docx daten.json "XX Kann-Liste <Thema>.docx"`
4. Kontrolle: mit LibreOffice in PDF umwandeln und die Seite ansehen (Logo, Kopfzeile, Titel, Tabelle, Seitenzahl). Dann die .docx an den Nutzer senden (bei verknüpftem Computer auch neben die Vorlage legen).

## make_kannliste.py
```python
#!/usr/bin/env python3
"""Kann-Liste aus der Originalvorlage erzeugen.
Aufruf: python3 make_kannliste.py vorlage.docx daten.json ausgabe.docx
Tabellenzeilen: 0-1 = Kopf, danach Themenzeile (2 Zellen) und Kompetenzzeile (4 Zellen).
"""
import json, re, sys, zipfile
from xml.sax.saxutils import escape

tpl, data_path, out = sys.argv[1:4]
data = json.load(open(data_path, encoding="utf-8"))
zin = zipfile.ZipFile(tpl)
doc = zin.read("word/document.xml").decode("utf-8")
hdr = zin.read("word/header1.xml").decode("utf-8")

def texts(x):
    return "".join(re.findall(r"<w:t(?: [^>]*)?>([^<]*)</w:t>", x))

def set_cell(tc, text):
    """Ersten Absatz/Lauf behalten (Formatierung), Text ersetzen, Rest entfernen."""
    ps = re.findall(r"<w:p[ >].*?</w:p>", tc, re.S)
    p = ps[0]
    allruns = re.findall(r"<w:r>.*?</w:r>|<w:r [^>]*>.*?</w:r>", p, re.S)
    runs = [r for r in allruns if "<w:t" in r] or allruns
    newp = p
    for r in allruns:
        newp = newp.replace(r, "", 1)
    newp = re.sub(r"<w:proofErr [^>]*/>", "", newp)
    base = re.sub(r"<w:t(?: [^>]*)?>[^<]*</w:t>|<w:tab/>|<w:br/>", "", runs[0])
    run = base.replace("</w:r>", '<w:t xml:space="preserve">%s</w:t></w:r>' % escape(text))
    newp = newp.replace("</w:p>", run + "</w:p>")
    tc = tc.replace(p, newp, 1)
    for extra in ps[1:]:
        tc = tc.replace(extra, "", 1)
    return tc

def fill(tr, vals):
    tcs = re.findall(r"<w:tc>.*?</w:tc>", tr, re.S)
    for tc, v in zip(tcs, vals):
        if v is not None:
            tr = tr.replace(tc, set_cell(tc, v), 1)
    return tr

trs = re.findall(r"<w:tr[ >].*?</w:tr>", doc, re.S)
body_rows = trs[2:]
sec_tpl = next(t for t in body_rows if len(re.findall(r"<w:tc>", t)) == 2)
item_tpl = next(t for t in body_rows if len(re.findall(r"<w:tc>", t)) == 4)

new = []
for i, ab in enumerate(data["abschnitte"], 1):
    new.append(fill(sec_tpl, [str(i), ab["titel"]]))
    for j, (text, tnw) in enumerate(ab["punkte"], 1):
        new.append(fill(item_tpl, [f"{i}.{j}", text, tnw, None]))

start = doc.index(body_rows[0]); end = doc.index(body_rows[-1]) + len(body_rows[-1])
doc = doc[:start] + "".join(new) + doc[end:]

# Titel: Absatz mit „Kann-Liste …“ neu setzen
for p in re.findall(r"<w:p[ >].*?</w:p>", doc[:start], re.S):
    if "Kann-Liste" in texts(p):
        tc_like = "<w:tc>" + p + "</w:tc>"
        doc = doc.replace(p, set_cell(tc_like, "Kann-Liste „%s“" % data["titel"])[6:-7], 1)
        break

# Kopfzeile: Zellen anhand ihres Textes ersetzen (Logo/Felder unangetastet)
repl = {"Biologie": data.get("fach", "Biologie"), "HF X": data.get("hf", "HF X"),
        "XX": data.get("hf2", "XX"), "AS": data.get("as", "AS"), "ZF": data.get("zf", "ZF")}
for tc in re.findall(r"<w:tc>.*?</w:tc>", hdr, re.S):
    t = texts(tc).strip()
    if t in repl and "<w:drawing" not in tc and "fldChar" not in tc and "instrText" not in tc:
        hdr = hdr.replace(tc, set_cell(tc, repl[t]), 1)

with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
    for item in zin.infolist():
        if item.filename == "word/document.xml":
            zout.writestr(item, doc)
        elif item.filename == "word/header1.xml":
            zout.writestr(item, hdr)
        else:
            zout.writestr(item, zin.read(item.filename))
print("OK:", out)
```