---
name: "kahoot-erstellen"
description: "Erstellt ein Kahoot-Quiz in der offiziellen Kahoot-Vorlage (KahootQuizTemplate.xlsx) samt Lösungsdatei. Immer nutzen, wenn die Lehrkraft „Kahoot erstellen“ sagt oder ein Kahoot-Quiz möchte."
---

# Kahoot erstellen

Grundlage ist eine Promptvorlage aus dem Kollegium des Joseph-DuMont-Berufskollegs. Fach, Klasse und Bildungsgang der Lehrkraft kennst du nicht: Du erfragst sie (siehe Parameter). Bei jüngeren Lerngruppen, an Förderschulen oder bei Deutsch als Zweitsprache formulierst du die Fragen besonders kurz, sprachsensibel und eindeutig.

**Ausgabe ist immer die offizielle Kahoot-Vorlage „KahootQuizTemplate.xlsx“, ausgefüllt.** Ist die Vorlage im Chat angehängt, diese Datei befüllen. Sonst baut das Skript unten sie originalgetreu nach.

## 1. Parameter klären
Fehlendes gesammelt in EINER Rückfrage abfragen (AskUserQuestion, falls verfügbar). Was sich aus Chat oder Dateien ergibt, nicht erneut fragen.
- **Fach** und **Thema** (ggf. Kann-Liste oder Blöcke)
- **Grundlage**: beigefügte Dateien, sonst Material aus dem Chat
- **Anzahl der Fragen** (Vorschlag: 20, höchstens 100)
- **Sprache** (Vorschlag: Deutsch)
- **Niveau**: Klasse/Bildungsgang, bei Fremdsprachen GER-Stufe
- **Erweiterungen** (optional):
  - humorvolle falsche Antworten
  - mindestens __ falsche Antworten sofort als eindeutig falsch erkennbar
  - gegenderte Formulierungen
  - höherer oder niedrigerer Schwierigkeitsgrad

Ist niemand da, der antworten kann: Standards nehmen (20 Fragen, Deutsch, Niveau der Lerngruppe) und sie oben in der Antwort nennen.

## 2. Regeln aus der Promptvorlage
- Fragen werden **schwieriger** (Wissen → Verstehen → Anwenden, Rechnen, Transfer).
- **Alle Formate**: Multiple Choice mit genau 4 Antworten und Wahr/Falsch (ca. ein Viertel). Wahr/Falsch hat zwei Antworten: „Wahr“, „Falsch“ (Englisch: „True“, „False“).
- **Frage max. 120 Zeichen, Antwort max. 75 Zeichen.** Das Skript prüft das.
- **Zeitlimit immer 30** Sekunden.
- Richtige Antwort als Zahl: a=1, b=2, c=3, d=4.
- Nur Inhalte aus der Grundlage, fachlich korrekt, genau eine richtige Antwort pro Frage.
- Ablenker plausibel und ähnlich lang wie die richtige Antwort, kein „alle genannten“. Die richtige Antwort ist nicht immer die längste.
- Richtige Antworten gleichmäßig auf die Positionen 1–4 verteilen.
- Erweiterungen nur umsetzen, wenn gewählt.

## 3. Dateien erzeugen
1. Fragen und Belege als JSON speichern:
```json
{"fragen": [{"frage": "Wie viele kcal liefert 1 g Fett?", "antworten": ["4 kcal", "7 kcal", "17 kcal", "9 kcal"], "richtig": 4, "zeit": 30},
            {"frage": "Wahr oder falsch: …", "antworten": ["Wahr", "Falsch"], "richtig": 1, "zeit": 30}],
 "loesungen": [{"typ": "Multiple Choice", "bezug": "1.2", "beleg": "Fette liefern 9 kcal pro Gramm."},
               {"typ": "Wahr/Falsch", "bezug": "…", "beleg": "…"}]}
```
   `bezug` ist z. B. ein Kann-Listen-Punkt oder eine Seite. `beleg` ist die für die Antwort relevante Textstelle, wörtlich oder eng zitiert.
2. Das Skript unten als `make_kahoot.py` speichern und ausführen:
   - mit angehängter Vorlage: `python3 make_kahoot.py daten.json "Kahoot <Thema> (Import).xlsx" vorlage.xlsx`
   - ohne Vorlage: dasselbe ohne das dritte Argument
3. Ergebnis: Die **Import-Datei** ist die Kahoot-Vorlage mit den Fragen ab Zeile 9 (Beispielfrage ersetzt). Daneben entsteht eine **separate Lösungsdatei** „(Loesungen)“ mit Nr. | Frage | Typ | richtige Antwort | Bezug | Textstelle. Die Lösungen stehen bewusst nicht in der Import-Datei, damit der Import nicht gestört wird.
4. Vor dem Senden:
   - Zeichenlängen und Verteilung der richtigen Antworten prüfen
   - einmal mit markitdown gegenlesen
   - beide Dateien senden; Dateinamen ohne Umlaute

## 4. Antwort im Chat
Kurz halten:
- Anzahl der Fragen und Anteil Wahr/Falsch
- Import-Weg: Kahoot → Frage hinzufügen → Tabelle importieren
- Hinweis: Wahr/Falsch kommt als Quizfrage mit zwei Antworten an

Die Fragen nicht zusätzlich als Tabelle in den Chat schreiben, außer die Lehrkraft möchte das.

## 5. Folgeaufträge
- „__ weitere Fragen“ (MC oder Wahr/Falsch): an die bestehende JSON anhängen und neu erzeugen
- Schwierigkeit anpassen
- humorvolle Ablenker
- eindeutig falsche Ablenker
- gendern

## make_kahoot.py
```python
#!/usr/bin/env python3
"""Kahoot-Quiz in die offizielle Kahoot-Vorlage (KahootQuizTemplate.xlsx) schreiben.
Aufruf: python3 make_kahoot.py daten.json "Kahoot <Thema> (Import).xlsx" [vorlage.xlsx]
Ohne vorlage.xlsx wird die Vorlage originalgetreu nachgebaut.
"""
import json, sys
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles.differential import DifferentialStyle
from openpyxl.worksheet.datavalidation import DataValidation

PURPLE = "FF461A8F"

def build_template():
    wb = Workbook(); ws = wb.active; ws.title = "Sheet1"
    band = PatternFill("solid", fgColor=PURPLE)
    white = PatternFill("solid", fgColor="FFFFFFFF")
    grey = PatternFill("solid", fgColor="FFF3F3F3")
    M = lambda **k: Font(name="Montserrat", **k)
    for r in range(1, 8):                       # lila Kopfbereich A1:I7
        for c in range(1, 10):
            ws.cell(r, c).fill = band
            ws.cell(r, c).font = M(sz=10 if r == 1 else 12)
    ws["B2"] = "Quiz template"; ws["B2"].font = M(sz=14, b=True, color="FFFFFFFF")
    texts = {3: ("Add questions, at least two answer alternatives, time limit and choose correct answers (at least one). Have fun creating your awesome quiz!", True),
             4: ("Remember: questions have a limit of 120 characters and answers can have 75 characters max. Text will turn red in Excel or Google Docs if you exceed this limit. If several answers are correct, separate them with a comma.", False),
             5: ("See an example question below (don't forget to overwrite this with your first question!)", False),
             6: ("And remember,  if you're not using Excel you need to export to .xlsx format before you upload to Kahoot!", False)}
    for r, (t, b) in texts.items():
        ws.cell(r, 2, t).font = M(sz=12, b=b, color="FFFFFFFF")
        if not b: ws.cell(r, 2).alignment = Alignment(horizontal="left")
    for rng in ("B3:H3", "B4:H4", "B6:H6"): ws.merge_cells(rng)
    heads = ["Question - max 120 characters", "Answer 1 - max 75 characters", "Answer 2 - max 75 characters",
             "Answer 3 - max 75 characters", "Answer 4 - max 75 characters",
             "Time limit (sec) – 5, 10, 20, 30, 60, 90, 120, or 240 secs", "Correct answer(s) - choose at least one"]
    ws.cell(8, 1).fill = band; ws.cell(8, 1).font = M(sz=12, color="FFFFFFFF")
    for i, h in enumerate(heads):
        c = ws.cell(8, 2 + i, h); c.font = M(sz=12, b=True, i=True, color="FF000000"); c.fill = grey
        c.alignment = Alignment(wrap_text=True)
    for r in range(9, 109):                     # Nummern 1–100 und weiße Eingabezellen
        a = ws.cell(r, 1, r - 8); a.fill = band; a.font = M(sz=12, color="FFFFFFFF")
        for c in range(2, 9):
            x = ws.cell(r, c); x.fill = white; x.font = M(sz=12)
            x.alignment = Alignment(wrap_text=True, horizontal="left" if c == 8 else None)
        ws.row_dimensions[r].height = 34 if r == 9 else 32 if r <= 28 else 25.5
    for r, h in {1: 18.75, 2: 57, 3: 36, 4: 15.75, 5: 15.75, 6: 18.75, 7: 18.75, 8: 51}.items():
        ws.row_dimensions[r].height = h
    for col, w in {"A": 12.5, "B": 49.33, "C": 31.83, "D": 31.83, "E": 31.83, "F": 31.83, "G": 26.33, "H": 33.16, "I": 11.5}.items():
        ws.column_dimensions[col].width = w
    red = DifferentialStyle(font=Font(color="FF9C0006"))
    for col, lim in (("B", 120), ("C", 75), ("D", 75), ("E", 75), ("F", 75)):
        rule = FormulaRule(formula=[f"LEN({col}9)>{lim}"]); rule.dxf = red
        ws.conditional_formatting.add(f"{col}9:{col}108", rule)
    return wb

tpl = sys.argv[3] if len(sys.argv) > 3 else None
data = json.load(open(sys.argv[1], encoding="utf-8"))
wb = load_workbook(tpl) if tpl else build_template()
ws = wb["Sheet1"] if "Sheet1" in wb.sheetnames else wb.active
Q = data["fragen"]
assert 1 <= len(Q) <= 100, "Kahoot-Vorlage fasst 1–100 Fragen"
for r in range(9, 109):                         # Beispielfrage und alte Inhalte leeren
    for c in range(2, 9): ws.cell(r, c).value = None
for i, q in enumerate(Q):
    assert len(q["frage"]) <= 120, ("Frage zu lang", q["frage"])
    ans = q["antworten"]
    assert 2 <= len(ans) <= 4 and all(len(a) <= 75 for a in ans), ("Antworten", ans)
    r = 9 + i
    ws.cell(r, 2).value = q["frage"]
    for j, a in enumerate(ans): ws.cell(r, 3 + j).value = a
    t = int(q.get("zeit", 30)); assert t in (5, 10, 20, 30, 60, 90, 120, 240)
    ws.cell(r, 7).value = t
    ok = str(q["richtig"]); assert all(1 <= int(x) <= len(ans) for x in ok.split(","))
    ws.cell(r, 8).value = int(ok) if "," not in ok else ok
dv = DataValidation(type="list", formula1='"5,10,20,30,60,90,120,240"', allow_blank=True)
ws.data_validations.dataValidation = [dv]; ws.add_data_validation(dv); dv.add("G9:G108")
wb.save(sys.argv[2])

# Lösungsdatei (separat, damit der Import nicht gestört wird)
L = data.get("loesungen")
if L:
    out = sys.argv[2].replace("(Import)", "(Loesungen)")
    if out == sys.argv[2]: out = sys.argv[2].replace(".xlsx", " (Loesungen).xlsx")
    lb = Workbook(); s = lb.active; s.title = "Lösungen & Belege"
    head = ["Nr.", "Frage", "Typ", "Richtige Antwort", "Bezug", "Relevante Textstelle"]
    hf = PatternFill("solid", fgColor="FF153E5E"); band2 = PatternFill("solid", fgColor="FFEAF0F4")
    for j, h in enumerate(head, 1):
        c = s.cell(1, j, h); c.font = Font(name="Arial", b=True, color="FFFFFFFF"); c.fill = hf
    for i, (q, l) in enumerate(zip(Q, L), start=2):
        right = ", ".join(q["antworten"][int(x) - 1] for x in str(q["richtig"]).split(","))
        for j, v in enumerate([i - 1, q["frage"], l.get("typ", ""), right, l.get("bezug", ""), l.get("beleg", "")], 1):
            c = s.cell(i, j, v); c.font = Font(name="Arial"); c.alignment = Alignment(wrap_text=True, vertical="top")
            if i % 2: c.fill = band2
    for col, w in zip("ABCDEF", [5, 55, 16, 38, 12, 70]): s.column_dimensions[col].width = w
    s.freeze_panes = "A2"; lb.save(out); print("OK:", out)
print("OK:", sys.argv[2], len(Q), "Fragen")
```