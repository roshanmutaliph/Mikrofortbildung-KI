---
name: "powerpoint-jdbk"
description: "Erstellt PowerPoint-Präsentationen (.pptx) im JDBK-Design mit Logo, Schulblau, Seitenzahl und großer Schrift für Prowise-Displays – mit Arbeitsaufträgen, ausgeblendeten Lösungen und Lehrernotizen; auch zum Umbauen vorhandener pptx."
---

# PowerPoint JDBK

Jede Präsentation für das Joseph-DuMont-Berufskolleg wird als **PowerPoint-Datei (.pptx)** im JDBK-Design gebaut – auch wenn ein Folien-Artifact verfügbar wäre. Zuerst den pptx-Skill laden (Skill-Tool, `anthropic-skills:pptx`) und dessen pptxgenjs-Regeln und QA befolgen; dieser Skill legt Design, Unterrichtslogik und Regeln fest.

Fehlen Angaben (Klasse, Fach, Thema, Dauer, Kann-Liste), mit sinnvollen Annahmen starten und diese am Ende kurz nennen, statt vorher viel nachzufragen.

## Design (nicht verändern)
- **Farben:** JDBK-Blau `103F5D` (aus dem Logo), Hellblau `E6EEF3` für Flächen/Karten, Gelb `F2A900` als Hervorhebung, Text `1A1A1A`, Grau `5A5A5A`, Grün `2E7D32` (✔), Rot `C62828` (✘). Weißer Folienhintergrund (Prowise-Displays spiegeln bei dunklen Flächen).
- **Schrift:** nur Arial. Titel 40 pt fett, blau, linksbündig, einzeilig (max. ca. 35 Zeichen – sonst kürzen). Fließtext 28 pt, 2. Ebene/Listen 24 pt, Karten/Tabellen 20–22 pt. **Nie unter 24 pt** für normalen Text; nur in Schaubildern/Tabellen bis 16 pt.
- **Logo** rechts oben auf jeder Folie (Titelfolie: weiß auf Blau). **Seitenzahl** unten rechts (außer Titelfolie). **Keine** Schulzeile/Fußzeile unten.
- Höchstens ca. 6 Zeilen pro Folie. Bei mehr Inhalt: auf mehrere Folien aufteilen, nicht verkleinern.

## Layouts (aus `jdbk_layouts.js`)
| Layout | Zweck | Platzhalter |
|---|---|---|
| `JDBK Titel` | Titelfolie, blauer Hintergrund | title, body (Klasse · Fach · Datum) |
| `JDBK Abschnitt` | Phasen-/Abschnittsfolie, hellblau | title, body |
| `JDBK Inhalt` | Titel + Text | title, body |
| `JDBK Zwei Spalten` | Vergleich | title, left, right |
| `JDBK Arbeitsauftrag` | Auftrag mit Kasten | title, meta (Sozialform · Zeit · Material), body (nummeriert) |
| `JDBK Nur Titel` | Schaubilder, Karten, Tabellen, Bilder, Tafelbilder | title |

## Arbeitsaufträge
- Layout `JDBK Arbeitsauftrag`. Meta-Zeile immer vollständig: **Sozialform · Zeit · Material** (z. B. „PA · 15 Min · M1, Gesetzestext“).
- Schritte nummeriert. Jeder Schritt beginnt mit dem **Operator in Fettdruck** (nennen, beschreiben, erklären, erläutern, vergleichen, begründen, beurteilen …) – pptxgenjs-Textruns: `{text:'Erläutere',options:{bold:true}}`.
- Letzte Zeile nennt die **Ergebnisform**: „Notiert eure Ergebnisse auf …“ / „Haltet fest in …“.

## Lösungen nicht zu früh zeigen
- Lösungsfolien stehen **direkt hinter ihrer Aufgabe** und werden **ausgeblendet** (`slide.hidden = true`). So erscheinen sie in der Präsentation nicht, bis die Lehrkraft sie einblendet oder gezielt anspringt.
- Wünscht die Lehrkraft es anders, alternativ alle Lösungen gesammelt am Ende hinter einer Abschnittsfolie „Lösungen“.
- Lösungsfolien tragen im Titel den Zusatz „Lösung“ (z. B. „Lösung · H3 Handlungsvollmacht“).

## Notizen für die Lehrkraft
Jede inhaltliche Folie bekommt Sprechernotizen (`slide.addNotes(...)`) mit:
- **Zeit** für diese Phase,
- **Impulsfragen** an die Klasse,
- **erwarteten Schülerantworten** bzw. Lösungsstichpunkten,
- ggf. Hinweisen zu typischen Fehlern.
Die Folie selbst bleibt dadurch schlank – Erklärtexte gehören in die Notizen, nicht auf die Folie.

## Sprachsensibel
- Kurze Hauptsätze, aktiv formuliert, eine Information pro Zeile.
- Fachbegriffe beim ersten Auftreten kurz erklären (z. B. „Prokura (= umfassende Vollmacht im Handelsrecht)“).
- Bei vielen neuen Begriffen eine Folie „Wichtige Begriffe“ (zweispaltig: Begriff | Erklärung in einfachen Worten) – hilft besonders Schüler*innen mit Deutsch als Zweitsprache.

## Folien zum Beschreiben am Prowise
- Für Sicherungen ein **Tafelbild** oder einen **Lückentext** auf `JDBK Nur Titel` bauen, mit sichtbar freien Flächen (hellblaue Kästen oder Lücken als „________“), die die Klasse am Touch-Display gemeinsam ausfüllt.
- Direkt danach (ausgeblendet, siehe „Lösungen nicht zu früh zeigen“) die Folie mit der Auflösung.

## Fachliche Absicherung
- Gesetzesbezüge (HGB, BGB, BBiG, ArbZG …) in einem **Zitatkasten** zeigen: hellblaue Fläche, blauer Rand links, Fundstelle fett („§ 49 Abs. 1 HGB“).
- Aktuellen Rechtsstand und Zahlen (Beitragssätze, Grenzwerte, Mindestlohn …) vor dem Bauen per **Websuche** prüfen.
- Ist etwas fachlich unklar oder widersprüchlich (z. B. Kann-Liste nennt „vier Arten“, Material nur drei), **nicht raten**, sondern am Ende im Chat als „Bitte prüfen“ auflisten.

## Bilder und Datenschutz
- Nur eigene, gemeinfreie oder frei lizenzierte Bilder (z. B. CC0, Pixabay, Unsplash, Wikimedia mit Lizenz); Quelle klein unter dem Bild oder auf einer Quellenfolie am Ende.
- Keine Fotos von realen Schüler*innen, keine echten Schülernamen – Beispielfälle mit erfundenen Namen und Betrieben.
- Wichtige Informationen nie nur über Farbe vermitteln (✔/✘ immer als Symbol).

## Kann-Liste
Bezieht sich der Inhalt auf eine **Kann-Liste** (H1, H2 …): eine Folie „Ich kann …“ mit allen Kann-Sätzen (zweispaltig: Kürzel | Satz) und je Kann-Satz eine Lösungsfolie mit Titel „H1 · …“. Fehlende Lösungen sachlich ergänzen und als zu prüfen nennen.

## Schaubilder
Hierarchien/Abläufe als Kästen in Blau/Hellblau mit grauen Winkel-Linien bauen; Wichtiges gelb hervorheben. Mehrere Arten nebeneinander als Karten (blauer Kopf, hellblauer Körper, „Beispiel:“ fett blau). Vergleiche als Tabelle mit blauer Kopfzeile.

## Vorhandene PowerPoint umbauen
Inhalte zuerst mit `slide_text.py` (pptx-Skill) auslesen, alles neu im JDBK-Design bauen, keine Inhalte weglassen, Tippfehler korrigieren und inhaltliche Fehler im Chat nennen. Zum Schluss Text von alt und neu vergleichen.

## Vorgehen
1. pptx-Skill laden. Arbeitsordner anlegen, darin das Logo und `jdbk_layouts.js` aus diesem Skill anlegen (unten).
2. Ggf. Websuche für Rechtsstand/Zahlen (siehe „Fachliche Absicherung“).
3. Deck-Skript schreiben:
   ```js
   const pptxgen=require('pptxgenjs'); const setup=require('./jdbk_layouts.js');
   const pres=new pptxgen(); const {C,save}=setup(pres);
   let s=pres.addSlide({masterName:'JDBK Titel'});
   s.addText('Thema',{placeholder:'title'}); s.addText('Klasse · Fach · Datum',{placeholder:'body'});
   s=pres.addSlide({masterName:'JDBK Arbeitsauftrag'});
   s.addText('Arbeitsauftrag',{placeholder:'title'});
   s.addText('PA · 15 Min · M1',{placeholder:'meta'});
   s.addText([{text:'1. ',options:{}},{text:'Lies',options:{bold:true}},{text:' den Fall M1.',options:{breakLine:true}}],{placeholder:'body'});
   s.addNotes('Zeit: 15 Min\nImpuls: …\nErwartet: …');
   s=pres.addSlide({masterName:'JDBK Inhalt'}); s.hidden=true; // Lösungsfolie
   s.addText('Lösung · …',{placeholder:'title'});
   // Farben immer über C.accent1 (Blau), C.background2 (Hellblau), C.accent2 (Gelb)
   save('10A_Wirtschaft_Prokura_2026-11-19.pptx');
   ```
4. `validate.py`, nach PDF rendern, jede Folie ansehen (Überlauf, Titel einzeilig, nichts unter dem Logo, Lösungsfolien ausgeblendet), korrigieren.
5. **Dateiname:** `Klasse_Fach_Thema_Datum.pptx` (Datum JJJJ-MM-TT, keine Leer- oder Sonderzeichen). Auf Wunsch zusätzlich als PDF (z. B. zum Hochladen in Teams) – dann ohne die ausgeblendeten Lösungsfolien exportieren.
6. .pptx an die Lehrkraft senden; ist ein Ordner verbunden, zusätzlich dorthin speichern. Kurz nennen: getroffene Annahmen und „Bitte prüfen“-Punkte.

## Logo anlegen
```bash
python3 - <<'PY'
import base64
from PIL import Image
open('logo_blau.png','wb').write(base64.b64decode("""iVBORw0KGgoAAAANSUhEUgAAAMgAAAD1BAMAAADnkqfeAAAAMFBMVEUPQVwPQFwPQF0PPWAPQF0OPmATOmIPPlwQQF4PPlwQQWAPPlwPPlwPPlwPPVsPPlwQZ9BkAAAAEHRSTlMgTZIgwEAA9fmg/4DAYCBA/dDRbgAACARJREFUeNrtnGtsFFUUgM/d6bZb2tJZoYCNkQZiAoZCSQGr1qRUfjQYoWgFTCQsCWKRR4qRh9TixlJDUaE/EB9gAiEgIElbDS3RQhcbQIyEEi1gQFhjFAh93E2A7m53e/1Bu+12Z2bvaxqNs39655F+c869555zz7kzqKEOTPo5tpX1tWxNrWZB3t7X37I5tpvESL4dadrCjWXmQEo9kWYCwEFTGMo+lBqRBCD0pBm9vmzQgQ0AQjXyIdUnwTYgVT7Ag3P3ZTOS2jDYRt4eJAn0FMuGzMWtQ9QF0OKWy6j0QM6gwwQAAAJ35JrIzejjh5KQk1KNpbRZCwLtMo2lqg5rQkhqnjwTOTaEERnMuFOasaz1gg4E2q9IYvTsAV0IOSrHWIILVX0IQJMUY6k+jY0gGddkKOsmASMIPivBWDbUak37+QPtwK8PRBm/dA16/ugJsr/vhT2LY6fmaVvUkahnWVmr7SXzBx8Jehb75ajn11QXAARFZhdHts6FIRB0V8BYdqTrXEAbhxwn3eL2IsnRJqI81qotCZAAt7EU6QkSA+EPwypbMTWEhPM4Xa4uQ0MS8jeXsaxpRvrRZH7sHHeWw1jsbf6Y59ezEwAAEvyRmRGekm5w1aZ1cs4+Zi/ixawQx3nWqPS64WVNSPgEo7HMbTa8nKB5Fn/LxDgwAbNLAtDJ4lmSm7uABwIhBoWV1sZbdeVrn+++fJ/Pi1DayUNjGUE7uwSb1Hi36EEAX6P0LHuLMTcEeunWLEnvxr9HH6KeoIpb56aLQDBuEfMiNBCA3lIhL0IHgSNxPUtRM6iCEPgk3sLNgwGLQjo8xsrKpxvlxhCywlBhH7tkQKD9VUMTwVIgZLL+ROl4gYAUCJBjupfKL4IkCDy4I2QidBCSV8bpRRgg4NOOW6sYIpr4EBLK1sxtgEwIoDsaxrLDKxdCQrEZEfsWkAsB8n1xTFSaJhsCuGVIL+/GWDqEkOi4NekigHQIkOi4dW4zNgECvuODYpfK09gMSYB0nBgItG6kgwkQBEA6I8WcJg82A0IAoP2N/l5/jZVBqy4AMrU/FJ8GpkFEfhbEglgQC2JBLIgFsSAWxIJYkP8PpLu/4VXNgyT3/Q2AeSstZ2QRP9EsSZScOe/3NRO6ChSnCRCnuiCv8Ol+dV3IXJzuZMIoNKnd4NJl16cMHLb8hN1Jvz1sq379548UaSggOSPL742LPhVqWJR8E0D1Iz9QQOKqC9nHnnfFnt50tBIBBiKlTxDafFj7yqqVxaqMjldBQRW62eeqQ7NVCRCMSIVBKTBw8HkZQzihwrDcGMhD4hDnM3FKmsu3ikPGxN1L/OYSUchCiuL/zgKKepMBxDaZZsZoEJPkOaoac6BKBBKk3Nz9lspf+82oojRnfwl/7beQuiBf7uKFZIyjdxe7ER8EFbrpIYGlKhdkNIMgANsxD4RJEAC7S2XeUoJI+iS2SGFXKrMkBPkZN8f0FLCriyxijay+YYeMZt7h1b2AFaKkMIfUiTNURoiNY2/fOtatV8jFDglkMUIe5VmDrFcBMUAyuHZCLjOI9DQgPhcPJLCARV2IS1sA81kgxMUHKWGBjObcnKqAbtwSA0H3OJe4/nrdxWSsJF/xLqSb6dWVzv1y2FaVGmLj3i+s0Bsj/9Z6P7UkaCx/dmMp7egiBfyQ9bSjK0Plh6AcSkiHWwDSSrmvPkEg4+SfSCnJAgEI1FBCFotAflepIETojdPXKSXJEoGE6SAZWASSiKkgYbcIxEcnidjbgIl0ECIEgdlUkDQxSBYNBBWJQSZQSSL4znQHDUQ4qa5SQMJZYgx7Fo26XGKQCi8NxANmDK9oiJplSg1Drrro2HXDAMH4v1BuohldKgxHx8MwDGEQHMK9VB3vHY6OF4T0ev8txUwkOHdVancQWus36fHdA4EPWmFVsS2IBbEgFsSCWJBhhiTI+1eH2xSdfIZEHz/9rxfvTUhym6quHl+o9u5nf86sMVMSZSQAIJXgkpeLTJNkLQAA6cJwsnpKjUmQoK9/ddN1yf/BU+ZAUmojlQ3SERqRWmcG5KPBqzTSmrhuk3yI41L0mpb4Dg0kZpVcORDUOTRwD3Zk3pUsyerYU7h7sVxIsk8jA4BPlUmFVGi+nxva65YI0Xl3liTekgjp0fkkBvmuWB5Et/qHz0iDKPN1Ez+hYlmQUwY5mXOSIIrLIIMVrJMCcUw1ypIhtxRIuWGuhARkQJJvxHE0MiClcfKWnW5xSNX++CVOUUjy9bglF48wpMhjfphafyl+krdAEPJRWVf8m1rF3O+BNAqG/bhQwF3p7Ih/k3pPJKp3rNpJc5svUaDjw/P209UL87ghjk9nNKVRZd2ddbxxV3XKl+D3A02OdN7P1H0SLL8/yxX5VGLz1S5CWQSxT6JfziU+vmXD+AlZhTe8vY0zNytptHUW9FIZwyIoXNIa2e5GqEs5yLnEzbAwVRpSOIrPJNvNNHcFvkDMDHVhHeMEWbKc8f0ZGDXnc+ZZeOu0HLYgxvcs+/pE8Wb7HPTlA2RbhTn8ib+xxKdS7yt6ZeAjmUwWHzqzeuxtKlnQtAf13J7xwydUiu5HKtp4XsD9vnNlHYyabnxPLjm7JiopwTxBhhrRrMwUg6+F5najeW0e8dzKnsxjf3i7NPVks9nXlEpK4Djeq70G4LT19s9jSMWPhDGU2Me4pWaJjoxw58LXfakhsBdf2FW/zZSk2tXTkNXrgYIfxuNNBqNtOKpz/wCbACtAl/XZGgAAAABJRU5ErkJggg=="""))
im=Image.open('logo_blau.png').convert('RGBA'); a=im.split()[3]
w=Image.new('RGBA',im.size,(255,255,255,0)); w.putalpha(a); w.save('logo_weiss.png')
im.save('logo_blau.png')
PY
```

## jdbk_layouts.js
```js
const { execSync } = require('child_process');
const THEME_JS = execSync("find / -name apply_theme.js -path '*pptx*' 2>/dev/null | head -1").toString().trim();
const { applyTheme } = require(THEME_JS);
module.exports = function setup(pres) {
  const BLUE='103F5D', DARK='1A1A1A', LIGHT='E6EEF3', GRAY='5A5A5A', ACC='F2A900';
  const THEME={name:'JDBK',headFontFace:'Arial',bodyFontFace:'Arial',colors:{dk1:DARK,lt1:'FFFFFF',dk2:BLUE,lt2:LIGHT,accent1:BLUE,accent2:ACC,accent3:'2E7D32',accent4:'C62828',accent5:'4F7F9E',accent6:GRAY,hlink:BLUE,folHlink:'5B2C83'}};
  pres.layout='LAYOUT_WIDE'; pres.theme={headFontFace:'Arial',bodyFontFace:'Arial'};
  pres.company='Joseph-DuMont-Berufskolleg';
  const C=pres.SchemeColor;
  const num={x:12.0,y:6.85,w:0.9,h:0.45,fontFace:'Arial',fontSize:16,bold:true,color:C.accent1,align:'right'};
  const logo={image:{path:'logo_blau.png',x:12.0,y:0.3,w:0.75,h:0.92}};
  const T=(o)=>({placeholder:{options:{name:'title',type:'title',align:'left',x:0.6,y:0.4,w:11.1,h:1.0,fontSize:40,bold:true,color:C.accent1,valign:'middle',...o},text:'Folientitel'}});
  const body=(name,x,y,w,h,text)=>({placeholder:{options:{name,type:'body',x,y,w,h,fontSize:28,color:C.text1,valign:'top',margin:[6,6,6,6]},text}});
  pres.defineSlideMaster({title:'JDBK Titel',background:{color:C.accent1},objects:[
    {image:{path:'logo_weiss.png',x:11.4,y:0.5,w:1.2,h:1.47}},
    {text:{text:'Joseph-DuMont-Berufskolleg Köln',options:{x:0.8,y:0.6,w:10,h:0.5,fontSize:18,color:C.background1,fontFace:'Arial'}}},
    T({x:0.8,y:2.3,w:10.4,h:1.8,fontSize:48,color:C.background1,valign:'bottom'}),
    {placeholder:{options:{name:'body',type:'body',x:0.8,y:4.3,w:11.7,h:1.2,fontSize:26,color:C.background2,valign:'top'},text:'Klasse · Fach · Datum'}}]});
  pres.defineSlideMaster({title:'JDBK Abschnitt',background:{color:C.background2},slideNumber:num,objects:[logo,
    T({x:0.8,y:2.4,w:11.7,h:1.6,fontSize:44}),
    {placeholder:{options:{name:'body',type:'body',x:0.8,y:4.0,w:11.7,h:1.0,fontSize:24,color:C.text1,valign:'top'},text:'Kurzer Untertitel'}}]});
  pres.defineSlideMaster({title:'JDBK Inhalt',background:{color:C.background1},slideNumber:num,objects:[logo,T({}),body('body',0.6,1.6,12.1,5.0,'Text')]});
  pres.defineSlideMaster({title:'JDBK Zwei Spalten',background:{color:C.background1},slideNumber:num,objects:[logo,T({}),
    body('left',0.6,1.6,5.85,5.0,'Linke Spalte'),body('right',6.85,1.6,5.85,5.0,'Rechte Spalte')]});
  pres.defineSlideMaster({title:'JDBK Arbeitsauftrag',background:{color:C.background1},slideNumber:num,objects:[logo,
    {rect:{x:0.6,y:1.55,w:12.1,h:5.05,fill:{color:C.background2},line:{type:'none'}}},T({}),
    {placeholder:{options:{name:'meta',type:'body',x:0.9,y:1.75,w:11.5,h:0.6,fontSize:22,bold:true,color:C.accent1,valign:'middle'},text:'Sozialform · Zeit · Material'}},
    body('body',0.9,2.45,11.5,4.0,'1. Lies …')]});
  pres.defineSlideMaster({title:'JDBK Nur Titel',background:{color:C.background1},slideNumber:num,objects:[logo,T({})]});
  const save=async(f)=>{await pres.writeFile({fileName:f}); await applyTheme(f,THEME);};
  return {C,THEME,save};
};
```