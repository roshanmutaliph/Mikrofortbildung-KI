---
name: "lern-app-lernsituation"
description: "Lern-App (JDBK, kaufmännisch): Baut aus Lernsituation/Szenario, Übungsblättern und Kann-Liste eine interaktive Lern-Webapp als HTML-Datei. Nutzen bei „Lern-App“, „Webanwendung aus Material“, „Masterprompt v3“."
---

# Lern-App aus Lernsituation (kaufmännisch, JDBK) – Masterprompt v3

Aus dem Material eines Themenbereichs – Lernsituation/Szenario, Übungsblätter, Kann-Liste (ggf. Infotexte und Lösungen) – entsteht eine vollständig funktionsfähige, interaktive Lern-App als EINE autarke HTML-Datei. Zielgruppe: Auszubildende in kaufmännischen Berufen am Berufskolleg. Pro Themenbereich eine App; alle Apps einer Reihe sehen gleich aus und nutzen dieselben Kernformate.

Leitsätze:
1. Berufliche Handlung statt Spielmechanik: Die Schüler tun, was Kaufleute tun – Belege prüfen, rechnen, Rechtslagen prüfen, entscheiden, kommunizieren.
2. Die Rolle als Azubi im Ausbildungsbetrieb ist die Rahmengeschichte. Keine fremden Metaphern (Tresor, Zahnrad, Wasserrohr).
3. Jede Interaktion bildet den fachlichen Denkschritt der Originalaufgabe ab und endet, wo sinnvoll, mit einer Warum-Frage.

---

## A. ARBEITSABLAUF

### Schritt 1 – Material sammeln und einlesen
- Benötigt: Szenario/Lernsituation, alle Übungsblätter, Kann-Liste. Hilfreich: Infotexte, Lösungen, Belege. Fehlt etwas, auf das sich das Material bezieht (Infoblatt, Gesetzestext, Beleg, Abbildung, Lösung), oder ist etwas unlesbar: nachfragen und um Zusendung bitten, bevor geplant wird.
- Word-Dateien: Text mit python-docx auslesen (Absätze, Tabellen UND Textboxen – w:txbxContent prüfen). Eingebettete Bilder per `unzip -l` finden.
- PDFs: Text extrahieren; Schaubilder, Tabellen und Belege visuell prüfen (Seite rendern und mit Read ansehen).
- Komplexe Schaubilder in Word: `soffice --headless --convert-to pdf`, dann `pdftoppm -r 110 -png`, dann Bilder mit Read ansehen.

### Schritt 2 – Steckbrief klären
Leite so viel wie möglich aus dem Material ab. Fehlende Punkte in EINER Runde erfragen (AskUserQuestion, max. 4 Fragen); sonst Standardwerte nehmen und in der Planung nennen.
- Bildungsgang / Klasse / Ausbildungsjahr
- Fach / Lernfeld / Lernsituation-Nr. / Themenbereich / Nummer in der Reihe
- Inhaltsschwerpunkt (mehrfach): Recht / Rechnen & Buchen / Prozesse / Kommunikation / Entscheiden
- Vorwissen zum Thema: neu (Standard) / teilweise bekannt / Wiederholung
- Sprachniveau: Standard B1, viele DaZ-Lernende
- Endgeräte: Standard Schüler-iPads + Prowise-Display
- Bearbeitungszeit: Standard 2 × 90 Minuten
- Lösungen im Material: ja / nein / teilweise
- Zusatzaufgaben über das Material hinaus: Standard nein (sonst max. 2 als „⭐ Plus“)
- „Einfach lesen“-Fassung: Standard nein
- Wiederholung aus vorherigem Themenbereich (optional): Kann-Punkte mit ID und Wortlaut
- Ablauf: Standard „mit Planung“; sagt die Lehrkraft „direkt“, Planung nur als Kurzfassung und sofort bauen.

### Schritt 3 – Planung (Phase 1, noch KEIN Code)
Sende der Lehrkraft eine kompakte Planung (SendUserMessage):
a) Materialcheck (was liegt vor, was fehlt).
b) Scope: Thema, Handlungssituation, Ausbildungsbetrieb und Personen, zentrale Problemfrage, Handlungsprodukt der Lernsituation.
c) Aufgaben-Mapping als Tabelle:
   Original-Nr. | Kurzinhalt | Operator | AFB | kaufmännische Tätigkeit | Format (K1–K7 oder Ergänzung + Grund) | Gerüst-Stufe (Beispiel / Lücke / frei) | im Mockup? | Kann-ID(s)
d) Verwechslungspaare und typische Fehler (Grundlage für Feedback und Abruf-Check).
e) Kann-Liste-Filter: übernommen (ID + exakter Wortlaut) und nicht übernommen (ID + Grund).
f) Prüfliste: jede selbst erstellte oder fachlich unsichere Lösung als [PRÜFEN] mit Fundstelle.
g) Annahmen zum Steckbrief.
Dann STOPP und auf „passt“ oder Änderungswünsche warten.

### Schritt 4 – Bauen (Phase 2)
Baue die App vollständig nach den Abschnitten B bis H als Datei im Arbeitsverzeichnis. Bei großen Apps in Etappen schreiben (Datenblock, dann Render-Funktionen je Format, dann Bereiche) – nie kürzen.

### Schritt 5 – Testen
- Script extrahieren und mit `node --check` auf Syntaxfehler prüfen.
- Nach externen Ressourcen suchen (`http`, `src=`, `@import`) – es darf keine geben.
- Doppelte IDs prüfen.
- Ist ein Headless-Browser verfügbar (z. B. Playwright/Chromium): Datei öffnen, durch alle Bereiche klicken, Konsole auf Fehler prüfen, je Format eine Aufgabe einmal richtig und einmal falsch beantworten, Druckbericht erzeugen.
- Die Qualitätskontrolle (Abschnitt H) abhaken.

### Schritt 6 – Ausliefern
- Datei senden (SendUserFile). Dateiname: [Fach]_[LF]_[LS]_[Thema]_v1.html (ohne Leerzeichen und Umlaute).
- Hinweis in einem Satz: Auf iPads läuft eine HTML-Datei aus Teams oder der Dateien-App oft nur als Vorschau ohne JavaScript – vorher auf einem Schülergerät testen oder als Link verteilen. Anbieten, die App als Artefakt-Link zu veröffentlichen.
- Danach höchstens 5 Zeilen „Hinweise für die Lehrkraft“ ([PRÜFEN]-Stellen, Annahmen, Test-Tipp).

---

## B. DESIGN & STYLEGUIDE (JDBK, VERBINDLICH)
- Primärfarbe JDBK-Blau #103F5D: Kopfzeile, Haupt-Buttons, aktive Tabs, Fortschrittsbalken. Hover/aktiv: #0B2C41.
- Flächen: Seitenhintergrund #F4F7FA; weiße Karten (#FFFFFF), Radius 12px, Rahmen #D9E2EC, dezenter Schatten. Arbeits- und Abschnittsflächen: Hellblau #E6EEF3.
- Akzent (sparsam): Gelb #F2A900.
- Feedback: Richtig #2E7D32 auf #E8F5E9 · Falsch #C62828 auf #FFEBEE · Tipp #B45309 auf #FEF3C7.
- Selbsteinschätzung (wie im Lernspaziergang), 4 Stufen: Grün #2E7D32 „kann ich sicher“ · Gelb #F2A900 „kann ich meistens“ · Orange #E8710A „kann ich teilweise“ · Rot #C62828 „kann ich noch nicht“.
- Typografie: system-ui, -apple-system, sans-serif; Fließtext #1A202C, 17px, Zeilenabstand 1.6.
- Kohärenz: kein Schmuck ohne Inhaltsbezug (keine Deko-Grafiken, Maskottchen, Hintergrundanimationen, Witze). Animation nur für Zustandswechsel und Feedback; prefers-reduced-motion respektieren.
- Grafik nur als geometrisches Inline-SVG (rect, circle, line, polygon, path), stroke-width 2.5, stroke-linecap round, Styleguide-Farben. Niemals Menschen, Gesichter, Hände oder Szenen zeichnen. Keine echten Firmenlogos nachbauen. Hochgeladene Bilder (z. B. Schullogo, Belege) dürfen per Code komprimiert als Base64 eingebettet werden (max. ca. 150 KB je Bild).
- Layout: Split-Screen (links Dokument/Quelle, rechts Bearbeitung/Live-Ergebnis) für prüfende, rechnende und vergleichende Aufgaben; unter 760px untereinander. Von 360px (Smartphone) bis Prowise-Display.
- Auswahlzustände sofort sichtbar (Rahmen, Badge, transition: all 0.25s ease).
- 🖥️ Tafelmodus (Schalter in der Kopfzeile): Schrift ca. 135 %, Buttons mind. 56px, hoher Kontrast; wichtige Bedienelemente auch unten erreichbar.

---

## C. TREUE ZUM MATERIAL & KANN-LISTE (KRITISCH)
1. Scope zuerst: zuerst NUR Szenario, Übungsblätter und zugehörige Infotexte analysieren.
2. Kann-Liste filtern: nur Punkte, die dieses Material tatsächlich abdeckt – mit Original-ID (z. B. A3) und exaktem Wortlaut. Nie Punkte anderer Themenbereiche übernehmen.
3. Vollständigkeit: jede Original- und Teilaufgabe umsetzen; Originalnummerierung und Reihenfolge beibehalten („2b“ bleibt 2b).
4. Operator und Anforderungsniveau bleiben erhalten: „Beurteilen Sie …“ wird nicht zur Klick-Aufgabe mit einer einzigen richtigen Antwort.
5. Fachliche Korrektheit: Lösungen zuerst aus dem Material. Paragrafen, Zahlen, Fristen, Kontenbezeichnungen und Kalkulationsschemata nur wie im Material oder sicher belegt; sonst [PRÜFEN]. Nichts erfinden.
6. Zusatzaufgaben nur laut Steckbrief, max. 2, als „⭐ Plus“ markiert.
7. Betrieb, Personen und Namen aus dem Material übernehmen. Keine echten Schülernamen, keine echten Markenlogos.

---

## D. DIDAKTISCHE STRUKTUR DER APP
Navigation über Tabs/Schritte + Fortschrittsbalken (Anteil bearbeiteter Aufgaben). 📖 Spickzettel aus jedem Bereich über die Kopfzeile erreichbar.

Start: Titel, Bildungsgang/LF/LS, Lernziele in Schülersprache („Am Ende kannst du …“), Zeitbedarf, Namensfeld (nur lokal gespeichert). Optional „🔁 Aufwärmen“: 3 Abruffragen zum vorherigen Themenbereich.

Bereich 1 – Szenario: der Arbeitsplatz
- Lernsituation als realistische, klickbare Arbeitsoberfläche des Ausbildungsbetriebs: E-Mail-Postfach, Kundenakte (CRM), Warenwirtschaft, Auftrags-/Ticketsystem, Messenger – mit Tabs, Badges, Avatar-Initialen, anklickbaren Anhängen.
- Das Mockup ist die Arbeitsumgebung der ganzen App: Aufgaben zu Belegen, Dokumenten oder Nachrichten öffnen sich dort (z. B. Aufgaben-Mail der Ausbilderin mit Anhang). Status-Badge „offen → in Bearbeitung → gelöst“.
- Das Szenario wirft die Problemfrage auf, verlangt aber keine Lösung ohne Fachwissen. Feld „Meine erste Einschätzung“ (freiwillig), das im Handlungsprodukt wieder erscheint.
- Darunter: klar gegliederter Arbeitsauftrag.

Bereich 2 – Erarbeitung & Training
- Alle Aufgaben in Originalreihenfolge, mit Badge für Kann-ID und Operator (antippbar mit Kurzerklärung).
- Jede Aufgabe: „💡 Tipp anzeigen“ (gestuft), „✅ Überprüfen“, „🔄 Zurücksetzen“, Status (offen / bearbeitet / richtig).
- Am Ende: Abruf-Check (E.3).

Bereich 3 – Handlungsprodukt (zurück an den Arbeitsplatz)
- Ausgangsproblem im Mockup lösen, meist mit K7 oder K6. Grundlage ist das Handlungsprodukt der Lernsituation.
- Erstellen → Kriterien-Checkliste abhaken → Musterlösung einblenden → abgleichen → „Meine erste Einschätzung“ daneben. Danach Mockup-Status „gelöst“.

Bereich 4 – Selbstcheck & Ergebnissicherung
- Gefilterte Kann-Liste mit 4-stufiger Farbskala.
- Kalibrierung: Selbsteinschätzung mit Aufgabenergebnissen und Sicherheitsangaben aus dem Abruf-Check vergleichen; bei Abweichung freundlicher Hinweis mit Sprung-Link.
- Feld „Was ist mir noch unklar?“.
- 🎧 Brücke zum Lernspaziergang: Button „Übungs-Prompt kopieren“ mit Thema und allen orange/rot eingeschätzten Kann-Punkten, z. B. „Ich lerne gerade [Thema]. Unsicher bin ich bei: [ID + Wortlaut]. Stell mir dazu nacheinander Fragen, gib mir zuerst Hinweise statt Lösungen und bleib bei diesem Thema.“
- 🖨️ „Ergebnisse als PDF speichern / drucken“.

📖 Spickzettel: Glossar als Seitenleiste/Overlay mit Suche und Flip-Cards; Verwechslungspaare als Gegenüberstellung; Fachbegriffe im Aufgabentext beim ersten Vorkommen antippbar; druckbar.

👩‍🏫 Lehrkraft-Ansicht: mit #lehrkraft in der Adresse oder 5× Tippen auf Logo/Titel alle Lösungen sichtbar, je Aufgabe Operator, AFB, Format, Kann-ID. Kein Schutz, nur Komfort.

---

## E. AUFGABENFORMATE – AUSWAHL UND PRIORISIERUNG

### E.1 Gestaltungsregeln (für alle Formate)
1. Format nach der kaufmännischen Tätigkeit wählen, nicht nach Abwechslung.
2. Warum-Frage: Jede geschlossene Aufgabe endet an mindestens einer Stelle mit einer Selbsterklärung – als FRAGE formuliert („Warum …?“, „Woran erkennst du …?“), nicht als Befehl. Antwort: zuerst eine von 3 Begründungen wählen (falsche = typische Fehlvorstellungen mit Erklärung); optional „Ich formuliere selbst“ mit Satzanfang.
3. Erst Beispiel, dann selbst: Bei Vorwissen „neu“ starten Rechen- und Prüfformate mit gelöstem Beispiel (A) → Beispiel mit Lücken (B) → eigene Lösung (C). Wer B im 1. Versuch löst, springt zu C. Vorwissen „teilweise“: Start bei B; „Wiederholung“: Start bei C.
4. Fehlerbeispiele erst nach korrekten Beispielen: Stufe D („Fehler finden“ in der Lösung eines fiktiven Azubis) frühestens nach C, immer: Was ist falsch? → Warum? → Wie richtig?
5. Pro App höchstens 5 verschiedene Formate; dasselbe Kernformat darf mehrfach vorkommen.
6. Dokumente, Belege und Nachrichten wo möglich im Mockup öffnen.
7. Keine Zeitlimits, Countdowns oder Ranglisten.

### E.2 Die 7 Kernformate (Priorität 1)
K1 · BELEG- & DOKUMENTEN-PRÜFER – prüfen/kontrollieren: Rechnung, Lieferschein, Angebot, Bestellung, Vertrag/AGB, Handelsregisterauszug, Kundenmail. Dokument links → verdächtige Stelle antippen → Fehlerart wählen → Korrektur → Warum-Frage. Auch korrekte Stellen bekommen Feedback. Variante Abgleich: 2–3 Dokumente nebeneinander (Bestellung – Lieferschein – Rechnung), Abweichungen verknüpfen. Stufe D: „Azubi X hat die Rechnung freigegeben – zu Recht?“

K2 · PRÜFSCHEMA (RECHT) – prüfen, ob eine Rechtsfolge eintritt (Kaufmannseigenschaft, Kaufvertrag, Mängelrechte, Vollmachtsumfang, Firmengrundsätze). Schema: Voraussetzung → Fallbezug → Zwischenergebnis → Ergebnis. A: gelöster Musterfall mit 1–2 Warum-Fragen; B: Lückenschema; C: neuer Fall; D: fehlerhaftes Azubi-Gutachten korrigieren. Optionale Brücken-Ansicht (Pfeiler = erfüllte Voraussetzung), nur bei kumulativen Voraussetzungen. Textstellen mit E3 markierbar.

K3 · RECHEN-WERKSTATT – berechnen/kalkulieren/buchen (Bezugs- und Angebotskalkulation, Prozent, Zinsen, Gewinnverteilung, Kennzahlen, Buchungssätze). Tabelle mit zeilengenauer Prüfung + Nebenrechnung; Stufen A → B → C; Fehlerdiagnose pro Zeile (Rabatt von falscher Basis, Skonto vor Rabatt, vom/im Hundert verwechselt, Soll/Haben vertauscht). Buchungssätze: Konten wählen, Betrag, Warum-Frage zu Kontenart und Zu-/Abgang. Pflicht am Ende: Deutungsfrage „Was bedeutet das Ergebnis für den Betrieb?“

K4 · VERWECHSLER – unterscheiden/abgrenzen/vergleichen bei ähnlichen Begriffen (Prokura/Handlungsvollmacht, Ist-/Kann-/Formkaufmann, OHG/KG, Aufwand/Auszahlung/Kosten, Gewährleistung/Garantie, Rabatt/Skonto/Bonus, Anfrage/Angebot/Bestellung) – nur Paare aus dem Material. (1) Merkmalstabelle mit Lücken; (2) 6–8 kurze Fälle GEMISCHT zuordnen; (3) pro Fall „Woran erkennst du das?“ – entscheidendes Merkmal antippen.

K5 · PROZESS-NAVIGATOR – Abläufe ordnen/darstellen (Beschaffung, Auftragsabwicklung, Reklamation, kaufmännisches und gerichtliches Mahnverfahren, Handelsregistereintragung). Schritte ordnen (Pfeile ↑↓ oder antippen → Position antippen) → Beleg/zuständige Stelle zuordnen → 1–2 Weichen entscheiden → Warum-Frage an einer Weiche.

K6 · ENTSCHEIDUNGS-WERKSTATT – beurteilen/entscheiden/empfehlen (Angebots- und Lieferantenvergleich, Rechtsformwahl, Kauf oder Leasing, Finanzierung). Variante Nutzwertanalyse (Gewichte per Regler, Summe 100 %, Ergebnis live, Reflexionsfrage zur Gewichtung) oder Argumente-Waage (SVG-Waage neigt sich). Pflicht: begründetes Fazit mit Satzbausteinen („Ich empfehle …, weil … Zwar …, aber …“). Feedback: Plausibilitätsprüfung + Kriterien-Checkliste + Musterfazit.

K7 · KOMMUNIKATIONS-WERKSTATT – formulieren/verfassen/beraten (Antwort auf Reklamation, Angebotsschreiben, Mahnung, Notiz, Kunden-/Verkaufsgespräch); Standard für das Handlungsprodukt. Schreiben: im Mockup, Textbausteine je Abschnitt (Anrede – Bezug – Kernaussage – Begründung – nächster Schritt – Gruß), ausblendbar; dann Kriterien-Checkliste, Stichwort-Hinweis (nie als Bewertung), Musterlösung. Gespräch: verzweigt mit 3–5 Entscheidungspunkten, jede Wahl mit Folge und Erklärung; oder Gesprächs-Coach (unprofessionelle Sätze ersetzen).

### E.3 Pflichtbaustein: ABRUF-CHECK (Ende Bereich 2)
- 6–10 kurze Fragen GEMISCHT über den Themenbereich; Verwechslungspaare abwechselnd.
- Auswahlfrage, Inline-Dropdown, Kurzrechnung; jede falsche Option = typische Fehlvorstellung mit Erklärung.
- Nach jeder Antwort „Wie sicher warst du?“ (sicher/unsicher) → Kalibrierung und Bericht.
- Fragen zusätzlich in APP_DATA.abrufCheck ablegen (für das Aufwärmen der nächsten App).

### E.4 Ergänzungsformate (Priorität 2 – nur, wenn kein Kernformat passt; Grund in der Planung nennen)
E1 Tap-to-Match / Kategorien-Sortierer (AFB I; mind. ein Element mit Warum-Frage) · E2 Dropdown-Lückentext (Definitionen, Fachsprache, DaZ) · E3 Text-Markierer (Gesetzes-/Falltext; Vorstufe zu K2) · E4 Satzbau-Baukasten (Gerüst in K6/K7, „erläutern“) · E5 Ursache-Wirkungs-Kette (wirtschaftliche Zusammenhänge, mit Warum-Frage) · E6 4-Quadranten-Matrix (nur wenn Modell im Material) · E7 Schieberegler-Simulation mit SVG-Diagramm (nur bei rechnerischem Zusammenhang im Material) · E8 Kennzahlen-Dashboard (nur bei Kennzahlen im Material, als echtes Controlling-Werkzeug).

### E.5 Nicht verwenden
Zahnrad, Wasserrohr, Thermostat, Tacho, Ressourcen-Fass, Röntgen-Regler, Lupe, Eisberg, Tresor/Safe-Knacker, Memory, Zeit-Challenges, Countdowns, Punkte-Ranglisten. Grund: fachfremde Metapher, Ablenkung oder Zeitdruck. Ausnahme: Das Material nutzt das Modell selbst (z. B. Eisbergmodell der Kommunikation) – dann als Schaubild.

### E.6 Entscheidungsweg pro Aufgabe
1. Welche kaufmännische Tätigkeit steckt in der Originalaufgabe (Operator + Inhalt)?
2. Zuordnung: prüfen/kontrollieren (Dokumente) → K1 · Rechtsfolge prüfen → K2 · berechnen/kalkulieren/buchen → K3 · unterscheiden/abgrenzen/vergleichen → K4 · Abläufe ordnen/darstellen → K5 · beurteilen/entscheiden/empfehlen → K6 · formulieren/verfassen/beraten → K7 · nennen/definieren (AFB I) → E1/E2 (oder K4 bei Abgrenzung) · erläutern/erklären → E4/E5 mit Warum-Frage.
3. Gerüst-Stufe nach Vorwissen festlegen.
4. Im Mockup möglich? → dort einbetten.
5. Warum-Frage und fehlerspezifisches Feedback formulieren.
6. Nur wenn kein K-Format passt: E-Format, Grund in der Planung.

---

## F. FEEDBACK, HILFEN & DIFFERENZIERUNG
- Erklärendes Feedback statt Haken: jede Antwortoption – auch jede falsche – mit eigener Erklärung zur typischen Fehlvorstellung. Aufbau: „Nicht ganz. [Was stimmt nicht] – [Warum: Regel/Merkmal] – [Hinweis, wie du weiterkommst]“. Beim 1. Versuch keine vollständige Lösung.
- Kein Raten durch Dauerklicken: 1. „Überprüfen“ markiert Fehler + Denkanstoß; 2. Versuch: Erklärung; „Lösung zeigen“ erst danach, im Bericht vermerkt.
- Gestufte Tipps (bis 3): Denkanstoß → Fachbegriff/Fundstelle → Satzanfang/Teillösung; Nutzung im Bericht (ohne Punktabzug).
- Offene Aufgaben: Stichwort-Check nur als Hinweis; Erwartungshorizont + Selbstabgleich per Checkliste.
- Punkte: 1. Versuch voll, 2. Versuch halb; offene Aufgaben „bearbeitet“, wenn Checkliste abgehakt.
- Optionen bei jedem Laden mischen; Prüfung über IDs, nie über Positionen.
- Sprachsensibel (Standard B1): kurze Sätze, aktiv, ein Arbeitsschritt pro Satz, Fachbegriffe und Operatoren erklärt; Satzbausteine ausblendbar; optional „Einfach lesen“ (fachlich gleichwertig).

---

## G. TECHNIK (STRIKT)
1. Eine Datei, datengetrieben: oben im Script EIN Objekt APP_DATA (meta: Titel, Bildungsgang, LF, LS, Version, Datum, appId; szenario; aufgaben[] mit format, stufen, feedback; abrufCheck[]; glossar[]; kannListe[]). Darunter eine Render-Funktion pro Format und ein zentraler State, aus dem neu gerendert wird. Keine Platzhalter, keine Kürzungen.
2. 100 % offline: keine externen URLs, Schriften, CDNs, Bibliotheken, kein fetch.
3. Fortschritt: localStorage (Schlüssel = appId) nach jeder Aktion, in try/catch. „Neu beginnen“ mit Bestätigung in der Oberfläche; „Meine Daten auf diesem Gerät löschen“. Keine Daten verlassen das Gerät.
4. Touch: Bedienelemente mind. 44px (Tafelmodus 56px); ohne Hover bedienbar; Zuordnen per Antippen–Antippen; Ziehen nur mit Pointer-Events (+ setPointerCapture) oder input type="range"; touch-action: none auf Zieh-Flächen, touch-action: manipulation auf Buttons; Tastatur (Tab, Enter) mit sichtbarem Fokus.
5. Keine alert(), confirm(), prompt(). Schülereingaben nur per textContent ausgeben.
6. Rechenfelder: Komma und Punkt als Dezimaltrennzeichen, Tausenderpunkte und „€“ ignorieren, auf 2 Nachkommastellen runden; inputmode="decimal".
7. Vorlesen: 🔊 neben jedem vorlesbaren Block (data-read-aloud="true"; nie Buttons, Tabs, Zeitstempel); speechSynthesis de-DE; Stimmen über voiceschanged laden; Stopp; Tempo normal/langsam; gelesener Block hervorgehoben; Hinweis, wenn keine deutsche Stimme.
8. Druck/PDF: Bericht per JavaScript in #print-report; @media print zeigt nur diesen; print-color-adjust: exact; break-inside: avoid. Inhalt: Name, Datum, App-Titel/LS; je Aufgabe Status, Punkte, Versuche, Tipps, „Lösung angesehen“; Freitexte und Begründungen; Handlungsprodukt; Abruf-Check mit Sicherheitsangaben; Kann-Liste farbig mit Kalibrierungshinweisen; „Was ist mir noch unklar?“.
9. Robustheit: eindeutige IDs, keine Konsolenfehler, Start auch ohne gespeicherten Stand.

---

## H. QUALITÄTSKONTROLLE VOR DEM AUSLIEFERN
- [ ] Jede Zeile der Mapping-Tabelle umgesetzt (gleiche Nummer, gleiches Format).
- [ ] Jede Aufgabe: Tipp, Überprüfen, Zurücksetzen, Kann-ID, Feedback mit Begründung für jede Option.
- [ ] Jede geschlossene Aufgabe hat mind. eine Warum-Frage (als Frage).
- [ ] Rechen-/Prüfformate mit Stufen passend zum Vorwissen; Fehlerbeispiele erst nach korrekten Beispielen.
- [ ] K3 mit Deutungsfrage, K6 mit begründetem Fazit, K7 mit Kriterien-Checkliste.
- [ ] Abruf-Check vorhanden, gemischt, mit Sicherheitsabfrage.
- [ ] Kein Format aus E.5; höchstens 5 verschiedene Formate.
- [ ] Jede Lösung aus dem Material oder als [PRÜFEN] gemeldet.
- [ ] Nur gefilterte Kann-Punkte, Wortlaut unverändert; Operator/AFB erhalten.
- [ ] Keine externen Ressourcen, kein alert(), keine doppelten IDs; `node --check` fehlerfrei.
- [ ] Druckbericht enthält alle Aufgaben, Abruf-Check und Kann-Liste.
- [ ] Texte entsprechen dem Sprachniveau.